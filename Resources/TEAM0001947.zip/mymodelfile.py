import timeit
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import AdaBoostRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import warnings
import itertools
import copy
import time
import logging
import numpy as np
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s', filename="logs_1.txt",
                    filemode="w")
logger = logging.getLogger(__name__)

class MyModel:
    warnings.filterwarnings("ignore")
    def __init__(self) -> None:
        self.start = time.time()
        self.regressor = AdaBoostRegressor()
        self.lb=LabelEncoder()
        self.features=['venue','batting_team','bowling_team']
        self.required_team_list=[
            "Rajasthan Royals",
            "Gujarat Titans",
            "Royal Challengers Bangalore",
            "Lucknow Super Giants",
            "Sunrisers Hyderabad",
            "Punjab Kings",
            "Delhi Capitals",
            "Mumbai Indians",
            "Chennai Super Kings",
            "Kolkata Knight Riders"
            ]
        self.required_venue_list=[
            'Narendra Modi Stadium',																					
            'MA Chidambaram Stadium',																						
            'Arun Jaitley Stadium',																				
            'M.Chinnaswamy Stadium',																						
            'Wankhede Stadium',																			
            'Dr DY Patil Sports Academy',																						
            'Punjab Cricket Association IS Bindra Stadium',																						
            'Sawai Mansingh Stadium',																					
            'Rajiv Gandhi International Stadium',																				
            'Eden Gardens',																						
            'Maharashtra Cricket Association Stadium',																					
            'Brabourne Stadium',																						
            'Himachal Pradesh Cricket Association Stadium',																					
            'Bharat Ratna Shri Atal Bihari Vajpayee Ekana Cricket Stadium'
            ]

    def fit(self, files_list):
        ball_by_ball_scores_data = files_list[0]
        match_results_data = files_list[1]
        ball_by_ball_scores_data["batter"] = ball_by_ball_scores_data["batter"].replace(
            {"KC Cariappa": "KC Kariappa"}
        )
        ball_by_ball_scores_data["BattingTeam"] = ball_by_ball_scores_data[
            "BattingTeam"
        ].replace(
            {
                "Kings XI Punjab": "Punjab Kings",
                "Delhi Daredevils": "Delhi Capitals",
                "Rising Pune Supergiants": "Rising Pune Supergiant",
            }
        )
        ball_by_ball_scores_data=ball_by_ball_scores_data[ball_by_ball_scores_data['BattingTeam'].isin(self.required_team_list)]
        match_results_data["Team1"] = match_results_data["Team1"].replace(
            {
                "Kings XI Punjab": "Punjab Kings",
                "Delhi Daredevils": "Delhi Capitals",
                "Rising Pune Supergiants": "Rising Pune Supergiant",
            }
        )
        match_results_data=match_results_data[match_results_data['Team1'].isin(self.required_team_list)]
        match_results_data["Team2"] = match_results_data["Team2"].replace(
            {
                "Kings XI Punjab": "Punjab Kings",
                "Delhi Daredevils": "Delhi Capitals",
                "Rising Pune Supergiants": "Rising Pune Supergiant",
            }
        )
        match_results_data=match_results_data[match_results_data['Team2'].isin(self.required_team_list)]

        # venue_df = match_results_data[["ID", "Venue"]]
        match_results_data['Venue']=match_results_data['Venue'].apply(lambda x:x.split(',')[0] if ',' in x else x)
        match_results_data=match_results_data[match_results_data['Venue'].isin(self.required_venue_list)]
        merged_data = pd.merge(
            ball_by_ball_scores_data, match_results_data,on="ID"
        )
        merged_data = merged_data.rename(columns={"Venue": "venue"})
        merged_data['bowling_team'] = merged_data.apply(lambda x: x['Team2'] if x['BattingTeam'] == x['Team1'] else x['Team1'], axis=1)
        merged_data = merged_data.rename(columns={"BattingTeam": "batting_team"})
        final = merged_data[merged_data["overs"] <= 6]
        final = (
            final.groupby(["ID", "innings"])
            .agg({'venue':'first',
                  'batting_team':'first',
                  'bowling_team':'first',
                  "total_run": "sum"})
            .reset_index()
        )
        cols = ["venue", "innings", "batting_team", 'bowling_team', "total_run"]
        final = final[cols]
        logger.info(f"col used to train : {final.columns}")
        min_out = final["total_run"].quantile(0.25)
        max_out = final["total_run"].quantile(0.75)
        iqr = max_out - min_out
        upper_limit = max_out + 1.5 * iqr
        lower_limit = min_out - 1.5 * iqr

        final["total_run"] = np.where(
            final["total_run"] > upper_limit,
            upper_limit,
            np.where(final["total_run"] < lower_limit, lower_limit, final["total_run"]),
        )
        final['batting_team']=self.lb.fit_transform(final['batting_team'])
        final['bowling_team']=self.lb.fit_transform(final['bowling_team'])
        final['venue']=self.lb.fit_transform(final['venue'])

        x = final.drop(columns=["total_run"], axis=1)
        y = final["total_run"]

        

        # Split the data into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(
            x, y, test_size=0.2, random_state=50
        )

        # Define the column transformer for preprocessing
       

        # Define the model pipeline
        self.model = AdaBoostRegressor()
        self.model.fit(X_train, y_train)
        logger.info(f"features {self.model.feature_names_in_}")

    def predict(self, test_data):
        test_data["venue"] = test_data["venue"].apply(lambda x: x.split(",")[0])
        test_data["batting_team"] = test_data["batting_team"].apply(lambda x: x.split(",")[0])
        test_data["bowling_team"] = test_data["bowling_team"].apply(lambda x: x.split(",")[0])
        cols = ["venue", "innings", "batting_team", 'bowling_team']
        test_data = test_data[cols]
        
        logger.info(f"col used to test : {test_data.columns}")
        for i in self.features:
            test_data[i]=self.lb.fit_transform(test_data[i])
        logger.info(f"fetuses to predict {test_data.columns }")
        test_df_pred = self.model.predict(test_data)

        flat_list = test_df_pred.tolist()

        print("Time Taken = ", time.time() - self.start)

        return flat_list

if __name__ == "__main__":
    start_time = timeit.default_timer()
    model_obj = MyModel()
    ball_by_ball_scores_data = pd.read_csv("iitm_data/DataSet/IPL_Ball_by_Ball_2008_2022.csv")
    match_results_data = pd.read_csv("iitm_data/DataSet/IPL_Matches_Result_2008_2022.csv")
    model_obj.fit([ball_by_ball_scores_data, match_results_data])
    test_file = pd.read_csv("iitm_data/FilesUsed/test_file_matchid_38.csv")
    prediction = model_obj.predict(test_file)
    logger.info(prediction)
    logger.info(type(prediction))
    end_time = timeit.default_timer()
    elapsed_time = end_time - start_time
    print(f"Elapsed time: {elapsed_time:.6f} seconds")
    