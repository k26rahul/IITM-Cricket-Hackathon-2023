# This is a dummy submission for the IPL power play score prediction hackathon.
# The code currently returns a dummy score for testing purposes only.
# As a beginner in programming and ML, I will be updating this code with real ML stuff for the real submission round.

class MyModel:
    def __init__(self):
        pass

    def fit(self, training_data):
        pass

    def predict(self, test_data):
        return [40, 40]
